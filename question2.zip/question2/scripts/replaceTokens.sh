#!/bin/bash
absolutePath() {
if [[ -d "$1" ]]; then
        cd "$1"
        echo "$(pwd -P)"
    else 
        cd "$(dirname "$1")"
        echo "$(pwd -P)/$(basename "$1")"
    fi
}

inputFile=$1
proFile=$2
outputFile=$3
declare -a arr
if [ "$#" -ne 3 ]; then
    echo "Illegal number of parameters"
else 
   echo "Original File Name: $inputFile"
   echo "Properties File Name: $proFile"
   echo "Output File Name: $outputFile"
   outputPath=`dirname $outputFile`
   outputPath=$(absolutePath "$outputPath")   
  if [ ! -d $outputPath ];
    then 
	  echo "outputPath : $outputPath"
	  mkdir -p $outputPath
  fi
  
  if [ -f $inputFile ];
    then    
     if [ -f $proFile ];
       then 
	     cp "$inputFile" /tmp/srcFile.tmp
		 while IFS='=' read -r proKey proValue; do
		   rpKey="\[\[$proKey\]\]"
		   rpValue="$proValue"
	       sed "s/$rpKey/$rpValue/g" /tmp/srcFile.tmp > /tmp/destFile.tmp
		   mv /tmp/destFile.tmp /tmp/srcFile.tmp
		   done < "$proFile"
		   
		   mv /tmp/srcFile.tmp "$outputFile"
	   else 
	     cp "$inputFile" "$outputFile"
     fi
    else 
	  echo "Please provide the correct input file."
   fi
fi
